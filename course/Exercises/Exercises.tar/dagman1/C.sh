#!/bin/sh

# Filename: C.sh
#

echo `cat C.input` after being massaged by Job C >> C.output

