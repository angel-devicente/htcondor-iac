#!/bin/sh

# Filename: D.sh
#

cat B.output C.output

