#!/bin/sh

# Filename: A.sh
#

echo This is the output of Job A for Job B > B.input
echo This is the output of Job A for Job C > C.input

