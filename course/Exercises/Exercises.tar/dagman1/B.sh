#!/bin/sh

# Filename: B.sh
#

echo `cat B.input` after being massaged by Job B >> B.output

